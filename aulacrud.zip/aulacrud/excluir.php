<?php
require('conexao.php');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    header('Location: index.php?erro=ID+invalido+para+exclusao.');
    exit();
}

try {
    $sql = "DELETE FROM cadastro WHERE id = :id"; 
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':id', $id, PDO::PARAM_INT);
    $statement->execute();
    
    header('Location: index.php?sucesso=Usuario+excluido+com+sucesso!');
    exit();
} catch (PDOException $e) {
    header('Location: index.php?erro=Erro+ao+excluir:+' . urlencode($e->getMessage()));
    exit();
}