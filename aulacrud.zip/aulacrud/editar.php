<?php
require('conexao.php');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    header('Location: index.php?erro=ID+invalido+para+edicao.');
    exit();
}

try {
    $sql = "SELECT * FROM cadastro WHERE id = :id";
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':id', $id, PDO::PARAM_INT);
    $statement->execute();
    $usuario = $statement->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        header('Location: index.php?erro=Usuario+nao+encontrado.');
        exit();
    }
} catch (PDOException $e) {
    header('Location: index.php?erro=Erro+ao+buscar+dados:+' . urlencode($e->getMessage()));
    exit();
}
?>

<!Doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Cadastro</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f9f9f9; }
        form { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 400px; }
        .form-control { display: block; margin-bottom: 10px; padding: 8px; width: 100%; box-sizing: border-box; }
        .btn-submit { background-color: #ffc107; color: black; border: none; padding: 10px 15px; cursor: pointer; border-radius: 4px; font-weight: bold; }
    </style>
</head>
<body>

    <h2>Editar Cadastro (ID: <?= $usuario['id'] ?>)</h2>
    
    <form action="atualizar.php" method="post">
        <input type="hidden" name="id" value="<?= $usuario['id'] ?>">

        <input class="form-control" type="text" name="nome" value="<?= htmlspecialchars($usuario['nome']) ?>" required>
        <input class="form-control" type="text" name="sobrenome" value="<?= htmlspecialchars($usuario['sobrenome']) ?>" required>
        <input class="form-control" type="date" name="datanasc" value="<?= htmlspecialchars($usuario['datanasc']) ?>" required>
        
        <input type="submit" value="Salvar Alterações" class="btn-submit">
        <a href="index.php" style="margin-left: 10px; color: #666; text-decoration: none;">Cancelar</a>
    </form>

</body>
</html>