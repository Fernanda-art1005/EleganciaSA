<?php
require('conexao.php');

$sucesso = filter_input(INPUT_GET, 'sucesso', FILTER_DEFAULT);
$erro = filter_input(INPUT_GET, 'erro', FILTER_DEFAULT);

try {
    $sql = "SELECT * FROM cadastro";
    $statement = $pdo->query($sql);
    $usuarios = $statement->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $erro = "Erro ao buscar dados: " . $e->getMessage();
}
?>

<!Doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Aula PHP - Início</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f9f9f9; }
        .alert-erro { background: #f8d7da; color: #721c24; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .alert-sucesso { background: #d4edda; color: #155724; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        form { margin-bottom: 40px; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 400px; }
        .form-control { display: block; margin-bottom: 10px; padding: 8px; width: 100%; box-sizing: border-box; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #f2f2f2; }
        .btn { padding: 5px 10px; text-decoration: none; border-radius: 3px; font-size: 14px; color: white; display: inline-block; }
        .btn-submit { background-color: #007bff; border: none; padding: 10px 15px; cursor: pointer; color: white; border-radius: 4px; }
        .btn-upd { background-color: #28a745; }
        .btn-del { background-color: #dc3545; }
    </style>
</head>
<body>

    <?php if ($erro): ?>
        <div class="alert-erro"><p style='margin:0;'><?= htmlspecialchars($erro) ?></p></div>
    <?php endif; ?>
    
    <?php if ($sucesso): ?>
        <div class="alert-sucesso"><p style='margin:0;'><?= htmlspecialchars($sucesso) ?></p></div>
    <?php endif; ?>

    <h2>Novo Cadastro</h2>
    <form action="cadastrar.php" method="post">
        <input class="form-control" type="text" name="nome" placeholder="Digite seu nome" required>
        <input class="form-control" type="text" name="sobrenome" placeholder="Digite seu sobrenome" required>
        <input class="form-control" type="date" name="datanasc" required>
        <input type="submit" value="Cadastrar" class="btn-submit">
    </form>

    <hr>

    <h2>Usuários Cadastrados</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Sobrenome</th>
                <th>Data de Nascimento</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($usuarios)): ?>
                <tr><td colspan="5" style="text-align: center;">Nenhum usuário cadastrado.</td></tr>
            <?php else: ?>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?= $usuario['id']; ?></td>
                        <td><?= htmlspecialchars($usuario['nome']); ?></td>
                        <td><?= htmlspecialchars($usuario['sobrenome']); ?></td>
                        <td><?= date('d/m/Y', strtotime($usuario['datanasc'])); ?></td>
                        <td>
                            <a href="editar.php?id=<?= $usuario['id']; ?>" class="btn btn-upd">Editar</a>
                            <a href="excluir.php?id=<?= $usuario['id']; ?>" class="btn btn-del" onclick="return confirm('Tem certeza?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>