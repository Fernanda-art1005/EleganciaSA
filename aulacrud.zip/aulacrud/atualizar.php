<?php
require('conexao.php');

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$nome = trim(filter_input(INPUT_POST, 'nome', FILTER_DEFAULT));
$sobrenome = trim(filter_input(INPUT_POST, 'sobrenome', FILTER_DEFAULT));
$datanasc = trim(filter_input(INPUT_POST, 'datanasc', FILTER_DEFAULT));

if (!$id || empty($nome) || empty($sobrenome) || empty($datanasc)) {
    header('Location: index.php?erro=Dados+invalidos+para+atualizacao.');
    exit();
}

try {
    $sql = "UPDATE cadastro SET nome = :nome, sobrenome = :sobrenome, datanasc = :datanasc WHERE id = :id";
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':id', $id, PDO::PARAM_INT);
    $statement->bindValue(':nome', $nome);
    $statement->bindValue(':sobrenome', $sobrenome);
    $statement->bindValue(':datanasc', $datanasc);
    $statement->execute();

    header('Location: index.php?sucesso=Usuario+atualizado+com+sucesso!');
    exit();
} catch (PDOException $e) {
    header('Location: index.php?erro=Erro+ao+atualizar:+' . urlencode($e->getMessage()));
    exit();
}