<?php

$pdo = new PDO('mysql:host=localhost; dbname=crudphp', 'root', '');

