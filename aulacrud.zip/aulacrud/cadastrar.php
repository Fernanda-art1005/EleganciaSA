<?php
require('conexao.php');

$nome = trim(filter_input(INPUT_POST, 'nome', FILTER_DEFAULT));
$sobrenome = trim(filter_input(INPUT_POST, 'sobrenome', FILTER_DEFAULT));
$datanasc = trim(filter_input(INPUT_POST, 'datanasc', FILTER_DEFAULT));

if (empty($nome) || empty($sobrenome) || empty($datanasc)) {
    header('Location: index.php?erro=Preencha+todos+os+campos.');
    exit();
}

try {
    $sql = "INSERT INTO cadastro (nome, sobrenome, datanasc) VALUES (:nome, :sobrenome, :datanasc)";
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':nome', $nome);
    $statement->bindValue(':sobrenome', $sobrenome);
    $statement->bindValue(':datanasc', $datanasc);
    $statement->execute();

    header('Location: index.php?sucesso=Usuario+cadastrado+com+sucesso!');
    exit();
} catch (PDOException $e) {
    header('Location: index.php?erro=Erro+ao+cadastrar:+' . urlencode($e->getMessage()));
    exit();
}